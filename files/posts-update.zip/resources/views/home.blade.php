@extends('layouts.app')

@section('content')
<div id="root">

</div>
@endsection

@section('scripts')
<script src="{{ asset('js/home.js') }}"></script>
@endsection
